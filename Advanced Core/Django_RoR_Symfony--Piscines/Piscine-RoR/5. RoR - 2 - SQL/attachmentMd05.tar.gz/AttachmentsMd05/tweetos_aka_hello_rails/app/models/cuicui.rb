class Cuicui < ApplicationRecord
end
